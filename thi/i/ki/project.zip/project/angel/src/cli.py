def main() -> None:
    # Startet das Skript, das auf Top-Level arbeitet
    import core.angel  # noqa: F401
    exit(0)