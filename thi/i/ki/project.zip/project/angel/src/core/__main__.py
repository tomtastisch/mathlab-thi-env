# erlaubt: python -m core
import core.angel  # noqa: F401  # führt das Skript aus